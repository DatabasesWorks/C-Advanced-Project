#include "items.h"
#include "ui_items.h"
#include "additems.h"
#include <exception>
#include <stdexcept>

items::items(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::items)
{
    ui->setupUi(this);
    db = Connection::getInstance();

    if(!db->connOpen())
    {
        qDebug() << "Error: Unable to connect to the database..";
    }

    ui->tableWidget->hideColumn(0);
    ui->tableWidget->hideColumn(4);
    ui->tableWidget->hideColumn(5);
    ui->tableWidget->hideColumn(6);
    fillTable();
}

items::~items()
{
    delete ui;
}

void items::fillTable()
{
    loading = true;

    int numRows,
        r,
        rowCount = 0,
        c;
    QSqlQuery query;
    QString categories [100][2];

    if(!query.exec("SELECT * from category"))
    {
        qDebug() << "Error selecting category: " << query.lastError().text();
    }
    query.next();
    do{
       categories[rowCount][0] = query.value(0).toString();
       categories[rowCount][1] = query.value(1).toString();
       rowCount++;
    }while (query.next());

    if(!query.exec("SELECT count(itemId) as numRows FROM item"))
    {
        qDebug() << query.lastError().text();
    }

    query.first();
    numRows = query.value(0).toInt();

    ui->tableWidget->setRowCount(numRows);

    if(!query.exec("SELECT * FROM item ORDER BY itemId"))
    {
        qDebug() << query.lastError().text();
    }

    for (r = 0, query.first(); query.isValid(); query.next(), r++)
    {
        for (c = 0; c < 8; c++)
        {
            if(c != 3)
            {
                ui->tableWidget->setItem(r,c, new QTableWidgetItem(query.value(c).toString()));
            }
            else
            {
                for (int i = 0; !categories[i][0].isEmpty(); i++)
                {
                    if (categories[i][0] == query.value(3).toString())
                    {
                        ui->tableWidget->setItem(r,c, new QTableWidgetItem(categories[i][1]));
                        break;
                    }
                }
            }
        }
    }
    loading = false;
}


void items::on_pushButton_Add_clicked()
{
   AddItems add;
   add.setModal(true);
   add.setWindowTitle("Add Item");

   QSqlQuery query;

   if (add.exec() == QDialog::Rejected)
   {
       qDebug() << "Item Creation Cancel..";
       ui->errorLabel->setText("Item not created");
       return;
   }
   try{
       if (add.getName() == "")
       {
           throw std::invalid_argument( "Name can't be empty" );
       }
       else if (add.getDescription() == "")
       {
           throw std::invalid_argument( "Description can't be empty" );
       }

       if(!query.exec("SELECT itemName FROM item ORDER BY itemId"))
       {
           qDebug() << "Error loading items: " << query.lastError().text();
       }

       int r;

       for (r = 0, query.first(); query.isValid(); query.next(), r++)
       {
           if(query.value(0).toString() == add.getName())
           {
               throw std::invalid_argument( "Name already exists");
           }
       }

   }catch (std::exception e)
   {
       ui->errorLabel->setText(QString("Error creating item: %1").arg(e.what()));
       return;
   }

   QString user = db->getUsername();

    if(!query.exec("INSERT INTO item (itemName, itemDescription, categoryId, itemUpdatedBy, itemQuantity) "
                   "VALUES ('"+add.getName()+"','"+add.getDescription()+"','"+add.getCategory()+"','"+user+"', '"+QString("%1").arg(add.getQty())+"')"))
    {
          qDebug() << "Error adding item: " << query.lastError().text();
    }

    fillTable();
}

void items::on_pushButton_Delete_clicked()
{
    int del_id = ui->tableWidget->item(ui->tableWidget->currentRow(), 0)->text().toInt();

    QSqlQuery query;

    query.prepare("DELETE FROM item WHERE itemId = :id");
    query.bindValue(":id", del_id);

    if(!query.exec()) {
        qDebug() << " Error deleting row: " << query.lastError().text();
    }
    fillTable();
}

void items::on_pushButton_Back_clicked()
{
    this->close();
}

void items::on_pushButton_Save_clicked()
{
    QSqlQuery query;

    QString categories [100][2];

    if(!query.exec("SELECT * from category"))
    {
        qDebug() << "Error selecting category: " << query.lastError().text();
    }

    int rowCount = 0;
    query.next();
    do{
       categories[rowCount][0] = query.value(0).toString();
       categories[rowCount][1] = query.value(1).toString();
       rowCount++;
    }while (query.next());

    QString name,
            description,
            category,
            qty,
            id;

    for(int row = 0; row < ui->tableWidget->rowCount(); row++)
    {
        try{
                name = ui->tableWidget->item(row,1)->text();
                description = ui->tableWidget->item(row,2)->text();
                bool successConversion;
                int cellValue = ui->tableWidget->item(row,7)->text().toInt(&successConversion);

                if (name == "")
                {
                    throw std::invalid_argument( "Name field can't be empty" );
                }

                if (description == "")
                {
                    throw std::invalid_argument( "Description field can't be empty" );
                }
                if (ui->tableWidget->item(row,7)->text() == "")
                {
                    throw std::invalid_argument( "Quantity field can't be empty" );
                }

                if (!successConversion)
                {
                    throw std::invalid_argument( "Quantity must be an integer" );
                }
                else if (cellValue < 0)
                {
                    throw std::invalid_argument( "Quantity must be greater than 0" );
                }

                bool found = false;

                for (int i = 0; !categories[i][0].isEmpty(); i++)
                {
                    if (categories[i][1] == ui->tableWidget->item(row,3)->text())
                    {
                        category = categories[i][0];
                        found = true;
                        break;
                    }
                }

                if(!found)
                {
                    throw std::invalid_argument( "Category not found");
                }

        } catch (std::exception e)
        {
            ui->errorLabel->setText(QString("Error in row %1: %2").arg((row+1)).arg(e.what()));

            return;
        };

        id = ui->tableWidget->item(row,0)->text();
        qty = ui->tableWidget->item(row,7)->text();
        QString user = db->getUsername();

        query.prepare("update item set itemName = '"+name+"', itemDescription = '"+description+"', "
                      "categoryId = '"+category+"',itemUpdatedBy = '"+user+"', itemQuantity = '"+qty+"' where itemId = '"+id+"'");

        if(!query.exec())
        {
            qDebug() << "Error saving: " << query.lastError().text();
        }
    }
   ui->errorLabel->setText("Saved Complete");
}

void items::on_tableWidget_cellChanged(int row, int column)
{
    ui->errorLabel->setText("Unsaved changes");
}
