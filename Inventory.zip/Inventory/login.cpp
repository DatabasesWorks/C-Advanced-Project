#include "login.h"
#include "ui_login.h"
#include "mainmenu.h"
#include "connection.h"
#include "modifyuser.h"
#include <QtSql>
#include <QMessageBox>
#include <stdexcept>
#include <exception>

using namespace std;

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);

    //connect to the database
    db = Connection::getInstance();

    if(!db->connOpen())
    {
        qDebug() << "Error connecting to database";
    }
}

Login::~Login()
{
    delete ui;
}

void Login::on_pushButton_login_clicked()
{
    QString username = ui->lineEdit_setUsername->text();
    QString password = ui->lineEdit_setPassword->text();

    QSqlQuery query;
    query.exec("SELECT username, password FROM login");

    if (query.isActive())
    {
        query.first();
    }
    else
    {
        qDebug() << "Not connected to database";
    }
    if(username == "" && password == "")
    {
        ui->label_loginStatus->setText("Neither \"USERNAME\" nor \"PASSWORD\" can be null.\n"
                                       "Please enter values for these fields in order to login.");
        qDebug () << "USERNAME and PASSWORD must have values.";

    }
    else if(username == "" && password != "")
    {
        ui->label_loginStatus->setText("\"USERNAME\" can't be null.\n"
                                       "Please, enter it now");
        qDebug () << "USERNAME must have a value.";
    }
    else if(username != "" && password == "")
    {
        ui->label_loginStatus->setText("\"PASSWORD\" can't be null.\n"
                                       "Please, enter it now.");
        qDebug () << "PASSWORD must have a value.";
    }
    else
    {
        QByteArray encript_loginPassword = password.toLocal8Bit();
        password = QString(QCryptographicHash::hash( (encript_loginPassword), QCryptographicHash::Sha1).toHex());
        //qDebug() << password; // This line is to see the password encripted

        do{
            if( query.value(0).toString().compare(username) != 0 )
            {

                    ui->label_loginStatus->setText("The username entered is \n"
                                                   "NOT REGISTERED. \n"
                                                   "Enter a different one");
            }
            else
            {
                if( query.value(1).toString().compare(password) != 0 )
                {
                    qDebug() << "The user is registered, but the password is wrong.";
                    ui->label_loginStatus->setText("You have provided incorrect credentials. \n"
                                                   "Enter them again.");
                    return;
                }
                else
                {
                    this->hide();
                    db->setPassword(password);
                    db->setUsername(username);
                    QMessageBox authenticationPassed;
                    authenticationPassed.setText("AUTHENTICATED");
                    authenticationPassed.exec();
                    return;
                }
            }
        }while(query.next());
    }
}

void Login::closeEvent(QCloseEvent *event)
{
    db->setClosePress(true);
    event->accept();
}
