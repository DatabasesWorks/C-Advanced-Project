#include "mainmenu.h"
#include "ui_mainmenu.h"

MainMenu::MainMenu(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainMenu)
{
    ui->setupUi(this);

    this->setWindowTitle("Menu");
    db = Connection :: getInstance();

    intro.setWindowTitle("Intro");
    intro.exec();

    login.setWindowTitle("Login");
    login.exec();

    if(db->getClosePress())
    {
        ui->products->setVisible(false);
        ui->report->setVisible(false);
        ui->settings->setVisible(false);
    }
}

MainMenu::~MainMenu()
{
    delete ui;
}

void MainMenu::on_exit_clicked()
{
    this->close();
}

void MainMenu::on_products_clicked()
{
    this->hide();
    products.setWindowTitle("Products");
    products.exec();
    this->show();
}

void MainMenu::on_settings_clicked()
{
    this->hide();
    settings.setWindowTitle("Settings");
    settings.exec();
    this->show();
}

void MainMenu::on_report_clicked()
{
    this->hide();
    report.setWindowTitle("Report");
    report.fillTable();
    report.exec();
    this->show();
}
