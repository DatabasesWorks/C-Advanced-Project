#ifndef MODIFYUSER_H
#define MODIFYUSER_H

#include <QDialog>
#include "connection.h"

namespace Ui {
class ModifyUser;
}

class ModifyUser : public QDialog
{
    Q_OBJECT

public:
    explicit ModifyUser(QWidget *parent = 0);
    ~ModifyUser();

private slots:

    void on_pushButton_back_clicked();

    void on_pushButton_save_clicked();

private:
    Ui::ModifyUser *ui;
    Connection *db;
};

#endif // MODIFYUSER_H
