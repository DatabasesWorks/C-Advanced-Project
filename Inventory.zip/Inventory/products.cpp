#include "products.h"
#include "ui_products.h"
#include "search.h"

Products::Products(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Products)
{
    ui->setupUi(this);
}

Products::~Products()
{
    delete ui;
}

void Products::on_pushButton_clicked()
{
    this->close();
}

void Products::on_pushButton_2_clicked()
{
    item.setModal(true);
    item.setWindowTitle("Items");
    this->hide();
    item.fillTable();
    item.exec();
}

void Products::on_pushButton_3_clicked()
{
    categories.setModal(true);
    categories.setWindowTitle("Categories");
    this->hide();
    categories.exec();
}

void Products::on_pushButton_4_clicked()
{
    Search search;
    search.setModal(true);
    search.setWindowTitle("Search");
    search.exec();
}
