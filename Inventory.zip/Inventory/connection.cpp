#include "connection.h"
#include <QDebug>

QString Connection::getPassword() const
{
    return password;
}

void Connection::setPassword(const QString &value)
{
    password = value;
}

bool Connection::getClosePress() const
{
    return closePress;
}

void Connection::setClosePress(bool value)
{
    closePress = value;
}

QString Connection::getUsername() const
{
    //    qDebug() << "Username return: " << username;
    return username;
}

void Connection::setUsername(const QString &value)
{
//    qDebug() << "Username set: " << value;
    username = value;
//    qDebug() << "Username now: " << username;
}
