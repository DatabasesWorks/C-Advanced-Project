#include "createuser.h"
#include "ui_createuser.h"
#include "connection.h"
#include <QCryptographicHash>
#include <stdexcept>
#include <exception>
#include <QDebug>
#include <QMessageBox>

CreateUser::CreateUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateUser)
{
    ui->setupUi(this);
    //connect to the database
    db = Connection::getInstance();
}

CreateUser::~CreateUser()
{
    delete ui;
}


void CreateUser::on_pushButton_create_clicked()
{
    QString newUsername = ui->lineEdit_newUser->text();
    QString password = ui->lineEdit_password->text();
    QString confirmPassword = ui -> lineEdit_confirmPassword->text();

    QSqlQuery addUser;
    QSqlQuery query;
    query.exec("SELECT username "
               "FROM login "
               "WHERE username = '"+newUsername+"';");
    query.first();






    try
    {
        if( newUsername == "" &&
            password == "" &&
            confirmPassword == "" )
        {
            throw std::invalid_argument("Create new user fields are empty.\n"
                                        "Enter them now.");
        }
        else if( newUsername == "" &&
                 password == "" &&
                 confirmPassword != "" )
        {
            throw std::invalid_argument("New user and password fields are empty.\n"
                                        "Enter them now.");
        }
        else if( newUsername == "" &&
                 password != "" &&
                 confirmPassword != "" )
        {
            throw std::invalid_argument("New user field is empty.\n"
                                        "Enter it now.");
        }
        else if( newUsername == "" &&
                 password != "" &&
                 confirmPassword == "" )
        {
            throw std::invalid_argument("New user and confirm password fields are empty.\n"
                                        "Enter them now.");
        }
        else if( newUsername != "" &&
                 password == "" &&
                 confirmPassword == "" )
        {
            throw std::invalid_argument("Password and confirm password fields are empty.\n"
                                        "Enter them now.");
        }
        else if( newUsername != "" &&
                 password != "" &&
                 confirmPassword == "" )
        {
            throw std::invalid_argument("Confirm password field is empty.\n"
                                        "Enter them now.");
        }
        else if( newUsername != "" &&
                 password == "" &&
                 confirmPassword != "" )
        {
            throw std::invalid_argument("Password field is empty.\n"
                                        "Enter it now.");
        }
        else if(password != confirmPassword)
        {
            throw std::invalid_argument("Password and confirm password fields are not the same.\n"
                                        "Enter them again.");
        }
        else
        {
            do
            {
                if(query.value(0).toString().compare(newUsername) == 0 )
                {
                    qDebug()  << "User found";
                    ui->label_createUserMessage->setText("That user is already registered.\n"
                                                         "Enter a different one.");



                }
                else
                {

                    this->close();
                    QByteArray encriptPassword = password.toLocal8Bit();
                    password = QString(QCryptographicHash::hash( (encriptPassword), QCryptographicHash::Sha1).toHex());
                    addUser.exec("INSERT into login (""username"",""password"")"
                                 "VALUES('"+newUsername+"','"+password+"')");
                    QMessageBox newUserCreated;
                    newUserCreated.setText("The user has been created\n"
                                              "SUCCESSFULLY.");
                    newUserCreated.exec();
                    query.first();
                    return;
                }
            }while(query.next());
        }

    }
    catch (std::exception &e)
    {
        ui->label_createUserMessage->setText(QString("Error creating new user:\n%1").arg(e.what()));
    }


}

void CreateUser::on_pushButton_back_clicked()
{
    this->close();
}
