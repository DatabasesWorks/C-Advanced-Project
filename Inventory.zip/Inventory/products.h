#ifndef PRODUCTS_H
#define PRODUCTS_H

#include <QDialog>
#include "items.h"
#include "categories.h"

namespace Ui {
class Products;
}

class Products : public QDialog
{
    Q_OBJECT

public:
    explicit Products(QWidget *parent = 0);
    ~Products();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Products *ui;

    items item;
    Categories categories;
};

#endif // PRODUCTS_H
