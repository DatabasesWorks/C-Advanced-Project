#include "addcategory.h"
#include "ui_addcategory.h"

AddCategory::AddCategory(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddCategory)
{
    ui->setupUi(this);
}

AddCategory::~AddCategory()
{
    delete ui;
}

void AddCategory::on_buttonBox_accepted()
{
    accept();
}

void AddCategory::on_buttonBox_rejected()
{
    reject();
}

QString AddCategory::getId() const
{
    return ui->id->text();
}

QString AddCategory::getName() const
{
    return ui->name->text();
}

QString AddCategory::getDescription() const
{
    return ui->description->text();
}
