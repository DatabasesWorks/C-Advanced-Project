#ifndef ITEMS_H
#define ITEMS_H

#include "connection.h"
#include <QDebug>
#include <QtSql>
#include <QDialog>

namespace Ui {
class items;
}

class items : public QDialog
{
    Q_OBJECT

public:
    void fillTable();
    explicit items(QWidget *parent = 0);
    ~items();

private slots:
    void on_pushButton_Add_clicked();

    void on_pushButton_Delete_clicked();

    void on_pushButton_Back_clicked();

    void on_pushButton_Save_clicked();

    void on_tableWidget_cellChanged(int row, int column);

private:
    Ui::items *ui;

    Connection *db;
    bool loading;
};

#endif // ITEMS_H
