#ifndef ADDITEMS_H
#define ADDITEMS_H

#include <QDialog>

namespace Ui {
class AddItems;
}

class AddItems : public QDialog
{
    Q_OBJECT

public:
    explicit AddItems(QWidget *parent = 0);
    ~AddItems();

    QString getName () const;
    QString getDescription () const;
    QString getCategory () const;
    int getQty () const;

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::AddItems *ui;
    QString categories [100][2];
};

#endif // ADDITEMS_H
