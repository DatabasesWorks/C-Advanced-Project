#include "settings.h"
#include "ui_settings.h"
#include <QMessageBox>
#include <QDebug>
#include "connection.h"
#include <QtSql>

Settings::Settings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Settings)
{
    ui->setupUi(this);
    db = Connection::getInstance();

}

Settings::~Settings()
{
    delete ui;
}


void Settings::on_pushButton_createNewUser_clicked()
{

    if(db->getUsername().compare("Admin") == 0 )
    {
        this->hide();
        createUser = new CreateUser (this);
        createUser->exec();
    }
    else
    {
        QMessageBox notAdmin;
        notAdmin.setText("This feature is only available to the\n"
                         "          ADMINISTRATOR");
        notAdmin.exec();
    }
}

void Settings::on_pushButton_ModifyUser_clicked()
{
    this->hide();
    modifyUser = new ModifyUser(this);
    modifyUser->exec();
}

void Settings::on_pushButton_back_clicked()
{
    this->close();
}

void Settings::on_pushButton_deleteUser_clicked()
{

    if(db->getUsername().compare("Admin") == 0 )
    {
        QString deleteUsername = ui->lineEdit_userToDelete->text();


        QSqlQuery query;
        query.exec("SELECT username FROM login");
        query.first();

        do
        {


            if(query.value(0).toString().compare(deleteUsername) != 0 &&
               deleteUsername!=("Admin"))
            {

                ui->label_deleteMessage->setText("User not registered.\n"
                                                 "Enter a different username.");

            }
            else
            {
                if(deleteUsername.compare("Admin") !=0 )
                {
                this->close();
                query.exec("DELETE FROM login WHERE username='"+deleteUsername+"'");
                QMessageBox userDeleted;
                userDeleted.setText("The user has been removed from the system.\n"
                                    "           SUCCESSFULLY.");
                userDeleted.exec();
                }
                else
                {
                    QMessageBox notAdmin;
                    notAdmin.setText("Admin can't be erased");
                    notAdmin.exec();
                    ui->label_deleteMessage->setText("Admin is protected");
                    return;
                }


            }
        }while(query.next());
    }
    else
    {
        QMessageBox notAdmin;
        notAdmin.setText("This feature is only available to the\n"
                         "          ADMINISTRATOR");
        notAdmin.exec();
    }













}

void Settings::on_pushButton_logOut_clicked()
{
    this->close();
    login.exec();
}
