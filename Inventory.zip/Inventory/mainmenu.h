#ifndef MAINMENU_H
#define MAINMENU_H

#include <QMainWindow>
#include <QDebug>

#include "connection.h"
#include "login.h"
#include "intro.h"
#include "products.h"
#include "settings.h"
#include "report.h"


namespace Ui {
class MainMenu;
}

class MainMenu : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainMenu(QWidget *parent = 0);
    ~MainMenu();

private slots:
    void on_exit_clicked();

    void on_products_clicked();

    void on_settings_clicked();

    void on_report_clicked();

private:
    Ui::MainMenu *ui;

    Connection *db;
    Login login;
    Intro intro;
    Products products;
    Settings settings;
    Report report;
};

#endif // MAINMENU_H
