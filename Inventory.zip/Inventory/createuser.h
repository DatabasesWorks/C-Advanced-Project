#ifndef CREATEUSER_H
#define CREATEUSER_H

#include <QDialog>
#include "connection.h"

namespace Ui {
class CreateUser;
}

class CreateUser : public QDialog
{
    Q_OBJECT

public:
    explicit CreateUser(QWidget *parent = 0);
    ~CreateUser();

private slots:

    void on_pushButton_create_clicked();

    void on_pushButton_back_clicked();

private:
    Ui::CreateUser *ui;
    Connection *db;
};

#endif // CREATEUSER_H
