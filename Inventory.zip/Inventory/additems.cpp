#include "additems.h"
#include "ui_additems.h"
#include <QString>
#include <QSqlQuery>
#include <exception>

AddItems::AddItems(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddItems)
{
    ui->setupUi(this);

    QSqlQuery query;
    int rowCount = 0;

    query.exec("SELECT * from category");
    query.next();
    do{
       categories[rowCount][0] = query.value(0).toString();
       categories[rowCount][1] = query.value(1).toString();
       rowCount++;
    }while (query.next());

    for (int i = 0; !categories[i][0].isEmpty(); i++)
    {
        ui->category->addItem(categories[i][1]);
    }
}

AddItems::~AddItems()
{
    delete ui;
}

void AddItems::on_buttonBox_accepted()
{
    accept();
}

void AddItems::on_buttonBox_rejected()
{
    reject();
}

QString AddItems::getName () const
{
    return ui->name->text();
}
QString AddItems::getDescription () const
{
    return ui->description->text();
}
QString AddItems::getCategory () const
{
    int selectedCategoryIndex;

    for (int i = 0; !categories[i][0].isEmpty(); i++)
    {
        if (categories[i][1] == ui->category->currentText())
        {
            selectedCategoryIndex = i;
            break;
        }
    }

    return categories[selectedCategoryIndex][0];
}
int AddItems::getQty() const
{
    return ui->qty->value();
}
