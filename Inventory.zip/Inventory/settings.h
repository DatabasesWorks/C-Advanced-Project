#ifndef SETTINGS_H
#define SETTINGS_H

#include <QDialog>
#include "createuser.h"
#include "modifyuser.h"
#include "connection.h"
#include "login.h"

namespace Ui {
class Settings;
}

class Settings : public QDialog
{
    Q_OBJECT

public:
    explicit Settings(QWidget *parent = 0);
    ~Settings();

private slots:

    void on_pushButton_createNewUser_clicked();

    void on_pushButton_ModifyUser_clicked();

    void on_pushButton_back_clicked();

    void on_pushButton_deleteUser_clicked();

    void on_pushButton_logOut_clicked();

private:
    Ui::Settings *ui;
    CreateUser *createUser;
    ModifyUser *modifyUser;
    Connection *db;
    Login login;
};

#endif // SETTINGS_H
