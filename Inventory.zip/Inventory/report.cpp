#include "report.h"
#include "ui_report.h"

Report::Report(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Report)
{
    ui->setupUi(this);
    db = Connection::getInstance();

    if(!db->connOpen())
    {
        qDebug() << "Error: Unable to connect to the database..";
    }

    ui->tableWidget->hideColumn(0);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    fillTable();
}

Report::~Report()
{
    delete ui;
}

void Report::fillTable()
{
    loading = true;

    int numRows,
        r,
        rowCount = 0,
        c;
    QSqlQuery query;
    QString categories [100][2];

    if(!query.exec("SELECT * from category"))
    {
        qDebug() << "Error selecting category: " << query.lastError().text();
    }
    query.next();
    do{
       categories[rowCount][0] = query.value(0).toString();
       categories[rowCount][1] = query.value(1).toString();
       rowCount++;
    }while (query.next());

    if(!query.exec("SELECT count(itemId) as numRows FROM item"))
    {
        qDebug() << query.lastError().text();
    }

    query.first();
    numRows = query.value(0).toInt();

    ui->tableWidget->setRowCount(numRows);

    if(!query.exec("SELECT * FROM item ORDER BY itemId"))
    {
        qDebug() << query.lastError().text();
    }

    for (r = 0, query.first(); query.isValid(); query.next(), r++)
    {
        for (c = 0; c < 8; c++)
        {
            if(c != 3)
            {
                ui->tableWidget->setItem(r,c, new QTableWidgetItem(query.value(c).toString()));
            }
            else
            {
                for (int i = 0; !categories[i][0].isEmpty(); i++)
                {
                    if (categories[i][0] == query.value(3).toString())
                    {
                        ui->tableWidget->setItem(r,c, new QTableWidgetItem(categories[i][1]));
                        break;
                    }
                }
            }
        }
    }
    loading = false;
}

void Report::on_pushButton_clicked()
{
    this->close();
}
