#ifndef REPORT_H
#define REPORT_H

#include "connection.h"
#include <QDebug>
#include <QtSql>
#include <QDialog>

namespace Ui {
class Report;
}

class Report : public QDialog
{
    Q_OBJECT

public:
    void fillTable();
    explicit Report(QWidget *parent = 0);
    ~Report();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Report *ui;
    Connection *db;
    bool loading;
};

#endif // REPORT_H
