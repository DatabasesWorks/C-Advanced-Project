#ifndef CATEGORIES_H
#define CATEGORIES_H

#include <QDialog>
#include <QtSql>
#include <QDebug>
#include "connection.h"

namespace Ui {
class Categories;
}

class Categories : public QDialog
{
    Q_OBJECT

public:
    explicit Categories(QWidget *parent = 0);
    ~Categories();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_Add_clicked();

    void on_pushButton_Save_clicked();

    void on_pushButton_Delete_clicked();

private:
    Ui::Categories *ui;
    Connection *db;
    bool loading;
    void fillTable();
};

#endif // CATEGORIES_H
