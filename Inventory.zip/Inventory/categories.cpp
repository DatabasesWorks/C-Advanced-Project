#include "categories.h"
#include "ui_categories.h"
#include "addcategory.h"
#include <exception>
#include <QMessageBox>
#include <stdexcept>

Categories::Categories(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Categories)
{
    ui->setupUi(this);
    db = Connection::getInstance();

    if(!db->connOpen())
    {
        qDebug() << "Error: Unable to connect to the database..";
    }

    ui->tableWidget->hideColumn(0);
    fillTable();
}

Categories::~Categories()
{
    delete ui;
}


void Categories::fillTable()
{
    loading = true;

    int numRows,
        r,
        c;
    QSqlQuery query;

    if(!query.exec("SELECT count(categoryId) as numRows FROM category"))
    {
        qDebug() << "Error counting categories: " << query.lastError().text();
    }

    query.first();
    numRows = query.value(0).toInt();

    ui->tableWidget->setRowCount(numRows);

    if(!query.exec("SELECT rowid, categoryId, categoryName, categoryDescription FROM category ORDER BY rowid"))
    {
        qDebug() << "Error loading categories: " << query.lastError().text();
    }

    for (r = 0, query.first(); query.isValid(); query.next(), r++)
    {
        for (c = 0; c < 4 ; c++)
        {
             ui->tableWidget->setItem(r,c, new QTableWidgetItem(query.value(c).toString()));
        }
    }

    loading = false;
}

//Back
void Categories::on_pushButton_clicked()
{
    this->close();
}

//Add
void Categories::on_pushButton_Add_clicked()
{
    AddCategory add;
    add.setModal(true);
    add.setWindowTitle("Add Category");
    QSqlQuery query;

    if (add.exec() == QDialog::Rejected)
    {
        ui->errorLabel->setText("Category not created");
        qDebug() << "Category Creation Cancel..";
        return;
    }
    try{
        if (add.getName() == "")
        {
            throw std::invalid_argument( "Name can't be empty" );
        }
        else if (add.getDescription() == "")
        {
            throw std::invalid_argument( "Description can't be empty" );
        }
        else if (add.getId() == "")
        {
            throw std::invalid_argument( "Id can't be empty" );
        }

        if(!query.exec("SELECT categoryId, categoryName FROM category ORDER BY rowid"))
        {
            qDebug() << "Error loading categories: " << query.lastError().text();
        }

        int r;

        for (r = 0, query.first(); query.isValid(); query.next(), r++)
        {
            if(query.value(0).toString() == add.getId())
            {
                throw std::invalid_argument( "Id already exist" );
            }
            if(query.value(1).toString() == add.getName())
            {
                throw std::invalid_argument( "Name already exist" );
            }
        }

    }catch (std::exception e)
    {
        ui->errorLabel->setText(QString("Error creating category: %1").arg(e.what()));
        return;
    }

     if(!query.exec("INSERT INTO category (categoryId, categoryName, categoryDescription) "
                    "VALUES ('"+add.getId()+"', '"+add.getName()+"', '"+add.getDescription()+"' )"))
     {
           qDebug() << "Error adding item: " << query.lastError().text();
     }

     fillTable();
}

void Categories::on_pushButton_Save_clicked()
{
    QSqlQuery query;

    QString rowid,
            id,
            name,
            description;

    for(int row = 0; row < ui->tableWidget->rowCount(); row++)
    {
        try{
                id = ui->tableWidget->item(row,1)->text();
                name = ui->tableWidget->item(row,2)->text();
                description = ui->tableWidget->item(row,3)->text();

                if (id == "")
                {
                    throw std::invalid_argument( "Id field can't be empty" );
                }

                if (name == "")
                {
                    throw std::invalid_argument( "Name field can't be empty" );
                }

                if (description == "")
                {
                    throw std::invalid_argument( "Description field can't be empty" );
                }
        } catch (std::exception e)
        {
            ui->errorLabel->setText(QString("Error in row %1: %2").arg((row+1)).arg(e.what()));
            return;
        };

        rowid = ui->tableWidget->item(row,0)->text();

        query.prepare("update category set categoryId = '"+id+"', categoryName = '"+name+"', "
                      "categoryDescription = '"+description+"' where rowid = '"+rowid+"'");

        if(!query.exec())
        {
            qDebug() << "Error saving: " << query.lastError().text();
        }
    }
    ui->errorLabel->setText("Saved Complete");
}

void Categories::on_pushButton_Delete_clicked()
{
    QMessageBox::StandardButton confirm;
    confirm = QMessageBox::question(this, "Warning", "You'll delete this category and all its items. Do you want to continue?",
                                    QMessageBox::Yes|QMessageBox::No);

    if (confirm == QMessageBox::No)
    {
      ui->errorLabel->setText("Deletion cancel");
      return;
    }
    else
    {
        QString del_id = ui->tableWidget->item(ui->tableWidget->currentRow(), 1)->text();

        QSqlQuery query;

        query.prepare("DELETE FROM item WHERE categoryId = :id");
        query.bindValue(":id", del_id);

        if(!query.exec())
        {
            qDebug() << " Error deleting items: " << query.lastError().text();
        }

        del_id = ui->tableWidget->item(ui->tableWidget->currentRow(), 0)->text();
        query.prepare("DELETE FROM category WHERE rowid = :id");
        query.bindValue(":id", del_id);

        if(!query.exec()) {
            qDebug() << " Error deleting category: " << query.lastError().text();
        }
        fillTable();
    }
}
