#ifndef CONNECTION
#define CONNECTION


#include <QtSql>
#include <QtDebug>

class Connection{

private:

    QSqlDatabase myDb;
    QString username;
    QString password;
    bool closePress = false;

    Connection() // this is a private constructor
    {
        myDb = QSqlDatabase::addDatabase("QSQLITE");
        myDb.setDatabaseName("../Inventory/restaurant.db");
    }

public:

    // function used to create a single instance
    static Connection *getInstance()
    {
            static Connection *instance = new Connection;
            return instance;
    }

    // closes the connection
    void connClose()
    {
        myDb.close();
    }

    // to open the connection before executing any query
    bool connOpen()
    {
        if(!myDb.open())
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    ~Connection(){}

    QString getUsername() const;
    void setUsername(const QString &value);
    QString getPassword() const;
    void setPassword(const QString &value);
    bool getClosePress() const;
    void setClosePress(bool value);
};

#endif // CONNECTION

