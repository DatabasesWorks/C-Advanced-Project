#include "search.h"
#include "ui_search.h"

Search::Search(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Search)
{
    ui->setupUi(this);
    db = Connection::getInstance();

    if(!db->connOpen())
    {
        qDebug() << "Error: Unable to connect to the database..";
    }

    ui->tableWidget->hideColumn(0);
    ui->tableWidget->hideColumn(4);
    ui->tableWidget->hideColumn(5);
    ui->tableWidget->hideColumn(6);
}

Search::~Search()
{
    delete ui;
}

//Back button
void Search::on_pushButton_2_clicked()
{
    this->close();
}

//Search button
void Search::on_pushButton_3_clicked()
{
    QString name = ui->name->text();

    if (name == "")
    {
        ui->errorLabel->setText("Item name can't be empty");
        return;
    }

    loading = true;
    int rowCount, c;
    ui->tableWidget->setRowCount(1);

    QSqlQuery query;
    QString categories [100][2];

    if(!query.exec("SELECT * from category"))
    {
        qDebug() << "Error selecting category: " << query.lastError().text();
    }
    query.next();
    do{
       categories[rowCount][0] = query.value(0).toString();
       categories[rowCount][1] = query.value(1).toString();
       rowCount++;
    }while (query.next());   

    if(!query.exec("SELECT * FROM item  WHERE itemName LIKE '"+name+"' ORDER BY itemId"))
    {
        qDebug() << query.lastError().text();
    }

    if(!query.next())
    {
        ui->errorLabel->setText("Item NOT found");
        found = false;

        for (c = 0; c < 8; c++)
        {
            ui->tableWidget->setItem(0,c, new QTableWidgetItem(""));
        }
        return;
    }

    ui->errorLabel->setText("Item Found");
    found = true;

    for (c = 0; c < 8; c++)
    {
       if(c != 3)
       {
           ui->tableWidget->setItem(0,c, new QTableWidgetItem(query.value(c).toString()));
       }
       else
       {
           for (int i = 0; !categories[i][0].isEmpty(); i++)
           {
               if (categories[i][0] == query.value(3).toString())
               {
                   ui->tableWidget->setItem(0,c, new QTableWidgetItem(categories[i][1]));
                   break;
                }
           }
        }
     }
    loading = false;
}

//Save button
void Search::on_pushButton_clicked()
{
    if(!found)
    {
        ui->errorLabel->setText("Item wasn't found. Error saving..");
        return;
    }

    QSqlQuery query;

    QString categories [100][2];

    if(!query.exec("SELECT * from category"))
    {
        qDebug() << "Error selecting category: " << query.lastError().text();
    }

    int rowCount = 0;
    query.next();
    do{
       categories[rowCount][0] = query.value(0).toString();
       categories[rowCount][1] = query.value(1).toString();
       rowCount++;
    }while (query.next());

    QString name,
            description,
            category,
            qty,
            id;
    int row = 0;

        try{
                name = ui->tableWidget->item(row,1)->text();
                description = ui->tableWidget->item(row,2)->text();
                bool successConversion;
                int cellValue = ui->tableWidget->item(row,7)->text().toInt(&successConversion);

                if (name == "")
                {
                    throw std::invalid_argument( "Name field can't be empty" );
                }

                if (description == "")
                {
                    throw std::invalid_argument( "Description field can't be empty" );
                }
                if (ui->tableWidget->item(row,7)->text() == "")
                {
                    throw std::invalid_argument( "Quantity field can't be empty" );
                }

                if (!successConversion)
                {
                    throw std::invalid_argument( "Quantity must be an integer" );
                }
                else if (cellValue < 0)
                {
                    throw std::invalid_argument( "Quantity must be greater than 0" );
                }

                bool found = false;

                for (int i = 0; !categories[i][0].isEmpty(); i++)
                {
                    if (categories[i][1] == ui->tableWidget->item(row,3)->text())
                    {
                        category = categories[i][0];
                        found = true;
                        break;
                    }
                }

                if(!found)
                {
                    throw std::invalid_argument( "Category not found");
                }

        } catch (std::exception e)
        {
            ui->errorLabel->setText(QString("Error: %1").arg(e.what()));

            return;
        };

        id = ui->tableWidget->item(row,0)->text();
        qty = ui->tableWidget->item(row,7)->text();   
        QString user = db->getUsername();

        query.prepare("update item set itemName = '"+name+"', itemDescription = '"+description+"', "
                      "categoryId = '"+category+"', itemUpdatedBy = '"+user+"' ,itemQuantity = '"+qty+"' where itemId = '"+id+"'");

        if(!query.exec())
        {
            qDebug() << "Error saving: " << query.lastError().text();
        }

   ui->errorLabel->setText("Saved Complete");
}

void Search::on_tableWidget_cellChanged(int row, int column)
{
    if (found)
    {
         ui->errorLabel->setText("Unsaved changes");
    }
}
