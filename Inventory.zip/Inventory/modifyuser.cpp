#include "modifyuser.h"
#include "ui_modifyuser.h"
#include "connection.h"
#include <QCryptographicHash>
#include <stdexcept>
#include <exception>
#include <QtSql>
#include <QMessageBox>

ModifyUser::ModifyUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ModifyUser)
{
    ui->setupUi(this);

    db = Connection::getInstance();
    ui->label_currentUsername->setText(db->getUsername());
    db->getPassword();
}

ModifyUser::~ModifyUser()
{
    delete ui;
}

void ModifyUser::on_pushButton_back_clicked()
{
    this->close();
}

void ModifyUser::on_pushButton_save_clicked()
{
    QString password = ui->lineEdit_currentPassword->text();
    QByteArray changedPassword = password.toLocal8Bit();
    password = QString(QCryptographicHash::hash( (changedPassword), QCryptographicHash::Sha1).toHex());

    QString newPassword = ui->lineEdit_newPassword->text();
    QByteArray encriptNewPassword = newPassword.toLocal8Bit();
    newPassword = QString(QCryptographicHash::hash( (encriptNewPassword), QCryptographicHash::Sha1).toHex());

    QSqlQuery query;
    query.exec("SELECT username FROM login");
    query.first();

    try
    {
        if( ui -> lineEdit_currentPassword    ->text() == "" &&
                ui -> lineEdit_newPassword        ->text() == "" &&
                ui -> lineEdit_confirmNewPassword ->text() == "" )
        {
            throw std::invalid_argument("All password reset fields are empty. \n"
                                        "Please enter them now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() != "" &&
                 ui -> lineEdit_newPassword        ->text() == "" &&
                 ui -> lineEdit_confirmNewPassword ->text() == "" )
        {
            throw std::invalid_argument("New password and confirm password fields are empty. \n"
                                        "Please enter them now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() != "" &&
                 ui -> lineEdit_newPassword        ->text() != "" &&
                 ui -> lineEdit_confirmNewPassword ->text() == "" )
        {
            throw std::invalid_argument("Confirm password field is empty. \n"
                                        "Please enter it now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() == "" &&
                 ui -> lineEdit_newPassword        ->text() != "" &&
                 ui -> lineEdit_confirmNewPassword ->text() == "" )
        {
            throw std::invalid_argument("Current password and confirm password fields are empty. \n"
                                        "Please enter them now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() == "" &&
                 ui -> lineEdit_newPassword        ->text() == "" &&
                 ui -> lineEdit_confirmNewPassword ->text() != "" )
        {
            throw std::invalid_argument("Current password field and new password fields are empty. \n"
                                        "Please enter them now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() == "" &&
                 ui -> lineEdit_newPassword        ->text() != "" &&
                 ui -> lineEdit_confirmNewPassword ->text() != "" )
        {
            throw std::invalid_argument("Current password field is empty. \n"
                                        "Please enter it now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() != "" &&
                 ui -> lineEdit_newPassword        ->text() == "" &&
                 ui -> lineEdit_confirmNewPassword ->text() == "" )
        {
            throw std::invalid_argument("New password and confirm password fields are empty. \n"
                                        "Please enter them now.");
        }
        else if( ui -> lineEdit_currentPassword    ->text() != "" &&
                 ui -> lineEdit_newPassword        ->text() == "" &&
                 ui -> lineEdit_confirmNewPassword ->text() != "" )
        {
            throw std::invalid_argument("New password field is empty.\n"
                                        "Please enter it now.");
        }
        else
        {



            if( db->getPassword().compare(password) != 0 )
            {

                throw std::invalid_argument("Passwords are different.\n"
                                            "Enter again");
            }
            else
            {
                if( ui->lineEdit_currentPassword->text().compare(ui->lineEdit_newPassword->text() ) == 0 )
                {
                    throw std::invalid_argument("New password must be different from the current one.");
                }
                else
                {
                    if( ui->lineEdit_newPassword->text().compare(ui->lineEdit_confirmNewPassword->text() ) !=0 )
                    {
                        throw std::invalid_argument("New password and confirm password fields must match.");
                    }
                    else
                    {
                        do
                        {
                            if(query.value(0).toString().compare(db->getUsername()) == 0)
                            {
                                this->close();
                                query.exec( "UPDATE login "
                                            "SET password= '" + newPassword + "'"
                                            "WHERE username='" + db -> getUsername() + "' ;" );
                                db->setPassword(newPassword);
                                QMessageBox passwordChangedOK;
                                passwordChangedOK.setText("Your password has been \n"
                                                          "updated SUCCESSFULLY.");
                                passwordChangedOK.exec();

                                return;
                            }
                        }while(query.next());
                    }
                }
            }
        }
    }

    catch (std::exception &e)
    {
        ui->label_message->setText(QString("Error updating password:\n%1").arg(e.what()));
    }
}
