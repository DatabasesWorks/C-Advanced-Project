#ifndef LOGIN_H
#define LOGIN_H
#include <QDialog>
#include "connection.h"
#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include <QCloseEvent>

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    ~Login();

private slots:
    void on_pushButton_login_clicked();

private:
    Ui::Login *ui;
    Connection *db;
    QSqlQuery query;
    void closeEvent(QCloseEvent *);
};

#endif // LOGIN_H
